<?php

namespace App\Http\Controllers;

use App\Merchant;
use App\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class MerchantController extends Controller
{
    public function loginMerchant(){
        return view('auth/login_merchant');
    }
    public function berandaMerchant(){
        $merchantid = Auth::user()->merchant->id;
        $merchant = Product::where('merchant_id', $merchantid)->get();
        return view('merchant/beranda_merchant', compact('merchant'));
    }
    public function editMerchant(){
        return view('merchant/edit_dagang', compact('merchant'));
    }
    public function tambahDagang(Request $request){
        $validator = Validator::make($request->all(), [
            'tanggal' => 'required|date',
            'title' => 'required',
            'satuan' => 'required',
            'deskripsi' => 'required',
            'harga' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors(['auth' => 'Tolong di isi dengan lengkap']);
        }
            $product = Product::create([
                'merchant_id' => Auth::user()->merchant->id,
                'tanggal' => $request->input('tanggal'),
                'title' => $request->input('title'),
                'satuan' => $request->input('satuan'),
                'deskripsi' => $request->input('deskripsi'),
                'harga' => $request->input('harga'),
                'status' => 'aktif'
        ]);
        if ($product) {
            $hari = now()->subDays(3);

            Product::where('status', 'aktif')
                ->where('tanggal', '<=', $hari)
                ->update(['status' => 'tidak aktif']);
        return redirect()->back()->with('success', 'Anda telah berhasil menambah promosi');
        }else {
            return redirect()->back()->with('error', 'Gagal menambah promosi, bila ada kendala silakan hubungi admin');
        }
    }
    public function EditprofileMerchant(){
        return view('merchant/edit_profile');
    }
    public function ProfileMerchant(){
        $merchant = Merchant::where('user_id', Auth::id())->first();
        return view('merchant/profile', compact('merchant'));
    }
    public function viewImg($type, $filename){
        $disk = '';

        if ($type === 'ktp') {
            $disk = 'public/ktp';
        }elseif ($type === 'skkb') {
            $disk = 'public/skkb';
        }elseif ($type === 'siup') {
            $disk = 'public/siup';
        }
        $img = storage_path("app/{$disk}/{$filename}");
        if(File::exists($img)){
            return response()->file($img);
        }
        return abort(404);
    }
}
