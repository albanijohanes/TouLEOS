$(window).on('load',function(){
$('#contactModal').modal('show');
});