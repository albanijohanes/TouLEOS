<style>

/* CSS untuk sidebar responsif */
@media (max-width: 768px) {
    #sidebar {
        display: none; /* Sembunyikan sidebar di layar kecil */
    }
}

/* CSS untuk menampilkan sidebar di layar besar */
@media (min-width: 768px) {
    #sidebar {
        display: block;
        /* Tambahkan gaya CSS lainnya sesuai kebutuhan Anda */
    }
}
/* CSS untuk tombol sidebar */
#sidebar-toggle {
    display: none; /* Sembunyikan tombol di layar besar */
}

/* Tampilkan tombol hanya di layar kecil */
@media (max-width: 768px) {
    #sidebar-toggle {
        display: block;
    }
    #sidebar {
        display: none; /* Sembunyikan sidebar di awal */
    }
    #sidebar.show {
        display: block; /* Tampilkan sidebar saat tombol diklik */
    }
}


</style>    
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $("#sidebar-toggle").click(function() {
            $("#sidebar").toggleClass("show");
        });
    });
</script>


<button id="sidebar-toggle" class="btn btn-primary d-lg-none">
                <i class="bi bi-list toggle-sidebar-btn"></i>
</button>

<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('porter')); ?>">
                <i class="bi bi-grid"></i>
                <span id="Judulmu">Dashboard</span>
            </a>
        </li><!-- End Dashboard Nav -->
        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('userporter')); ?>">
                <i class="bi bi-person"></i>
                <span id="Judulmu">Profil Anda</span>
            </a>
        </li><!-- End Profile Page Nav -->
    </ul>
</aside><!-- End Sidebar -->
<?php /**PATH C:\laragon\www\TouLEOS\resources\views/layouts/_sidebar.blade.php ENDPATH**/ ?>